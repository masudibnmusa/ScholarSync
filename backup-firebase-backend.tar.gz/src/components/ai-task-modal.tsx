"use client";

import { useAppStore } from "@/lib/store";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  Sparkles,
  CheckCircle2,
  XCircle,
  Edit2,
  Quote,
  Brain,
  Target,
} from "lucide-react";
import { cn } from "@/lib/utils";

export function AITaskModal() {
  const { showAIModal, dismissAIModal } = useAppStore();

  // AI task suggestions would come from the NLP engine in production
  const aiTaskSuggestions: Array<{
    id: string;
    task: string;
    deadline: string;
    assignee: string;
    confidence: number;
    source: string;
  }> = [];

  return (
    <Dialog open={showAIModal} onOpenChange={(open) => !open && dismissAIModal()}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-violet-100 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-violet-600" />
            </div>
            <div>
              <DialogTitle className="text-lg">AI Task Suggestions</DialogTitle>
              <p className="text-xs text-muted-foreground">
                NLP engine extracted actionable tasks from team chat
              </p>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-3 mt-2">
          {aiTaskSuggestions.map((suggestion) => (
            <Card key={suggestion.id} className="border-border/50 p-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                  <Target className="w-4 h-4 text-primary" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-semibold text-sm">{suggestion.task}</h4>
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[10px] border",
                        suggestion.confidence >= 0.9
                          ? "border-emerald-200 text-emerald-600 bg-emerald-50"
                          : suggestion.confidence >= 0.8
                            ? "border-amber-200 text-amber-600 bg-amber-50"
                            : "border-blue-200 text-blue-600 bg-blue-50"
                      )}
                    >
                      <Brain className="w-3 h-3 mr-1" />
                      {Math.round(suggestion.confidence * 100)}% confidence
                    </Badge>
                  </div>

                  <div className="flex items-center gap-3 mb-2 text-xs text-muted-foreground">
                    <span>Assignee: {suggestion.assignee}</span>
                    <span>•</span>
                    <span>Deadline: {suggestion.deadline}</span>
                  </div>

                  <div className="flex items-start gap-2 p-2 rounded-lg bg-muted/50 text-xs">
                    <Quote className="w-3 h-3 text-muted-foreground shrink-0 mt-0.5" />
                    <span className="text-muted-foreground italic leading-relaxed">
                      Source: {suggestion.source}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 mt-3">
                    <Button size="sm" className="gap-1 h-7 text-xs">
                      <CheckCircle2 className="w-3 h-3" />
                      Accept & Add to Board
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-1 h-7 text-xs"
                    >
                      <Edit2 className="w-3 h-3" />
                      Edit
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="gap-1 h-7 text-xs text-muted-foreground"
                    >
                      <XCircle className="w-3 h-3" />
                      Dismiss
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
