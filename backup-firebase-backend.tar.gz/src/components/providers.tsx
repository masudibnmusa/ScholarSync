"use client";

import { useEffect } from "react";
import { auth } from "@/lib/firebase";
import { onAuthStateChanged } from "firebase/auth";
import { useAppStore } from "@/lib/store";

export function Providers({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      const store = useAppStore.getState();
      if (user) {
        try {
          await store.fetchProfile();
          store.fetchTeams();
          store.fetchNotifications();
        } catch (err) {
          console.error("Failed to load user data:", err);
        }
        store.setLoading(false);
      } else {
        store.setCurrentUser(null);
        store.setView("login");
        store.setLoading(false);
      }
    });
    return () => unsubscribe();
  }, []);

  return <>{children}</>;
}
