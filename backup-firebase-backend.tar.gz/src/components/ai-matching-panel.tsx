"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import {
  BrainCircuit,
  Sparkles,
  Users,
  CheckCircle2,
  ArrowLeftRight,
  RotateCcw,
  Play,
  Zap,
  Target,
  Shuffle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAppStore } from "@/lib/store";

export function AIMatchingPanel() {
  const { teams } = useAppStore();
  const [isRunning, setIsRunning] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  const algorithmSteps = [
    { label: "Profile Analysis", status: "done" },
    { label: "Skill Clustering", status: "done" },
    { label: "Availability Matching", status: "done" },
    { label: "Balance Optimization", status: "done" },
    { label: "Team Assignment", status: "pending" },
  ];

  const suggestedTeams = [
    {
      name: "Suggested Team A",
      members: ["Sara Islam", "Rahim Uddin", "Kamal Hossain"],
      score: 94,
      strengths: ["Balanced skills", "Complementary schedules"],
    },
    {
      name: "Suggested Team B",
      members: ["Fatima Akter", "Tanvir Ahmed", "Nusrat Jahan"],
      score: 91,
      strengths: ["Diverse expertise", "Strong communication"],
    },
    {
      name: "Suggested Team C",
      members: ["Masud Ibn Musa", "Md Nazmul Hasan", "Chinmoy Kumar"],
      score: 87,
      strengths: ["High skill overlap", "Similar availability"],
    },
  ];

  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto h-full overflow-y-auto">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-xl font-bold">AI Team Matching</h2>
          <p className="text-sm text-muted-foreground">
            Run the clustering algorithm to form balanced project teams
          </p>
        </div>
        <Button
          size="sm"
          className="gap-1.5"
          onClick={() => {
            setIsRunning(true);
            setTimeout(() => {
              setIsRunning(false);
              setIsComplete(true);
            }, 2500);
          }}
          disabled={isRunning}
        >
          {isRunning ? (
            <>
              <RotateCcw className="w-3.5 h-3.5 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5" />
              Run Algorithm
            </>
          )}
        </Button>
      </div>

      {/* Algorithm Status */}
      <Card className="border-border/50">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <BrainCircuit className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">Heuristic Matching Engine</h3>
            <Badge variant="secondary" className="text-[10px]">
              Scikit-learn K-Means Clustering
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-muted-foreground font-medium mb-2">
                Algorithm Parameters
              </p>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Students</span>
                  <span className="font-medium">9</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Team Size</span>
                  <span className="font-medium">3 per team</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Weights</span>
                  <div className="flex items-center gap-1.5">
                    <Badge variant="secondary" className="text-[10px]">
                      Skills 40%
                    </Badge>
                    <Badge variant="secondary" className="text-[10px]">
                      Schedule 30%
                    </Badge>
                    <Badge variant="secondary" className="text-[10px]">
                      Interests 30%
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <p className="text-xs text-muted-foreground font-medium mb-2">
                Pipeline Steps
              </p>
              <div className="space-y-1.5">
                {algorithmSteps.map((step) => (
                  <div
                    key={step.label}
                    className={cn(
                      "flex items-center gap-2 text-sm p-1.5 rounded-md",
                      step.status === "done"
                        ? "text-emerald-600 bg-emerald-50"
                        : "text-muted-foreground"
                    )}
                  >
                    {step.status === "done" ? (
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    ) : isRunning ? (
                      <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Target className="w-3.5 h-3.5" />
                    )}
                    {step.label}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {isRunning && (
            <div className="p-3 rounded-lg bg-primary/5 border border-primary/10">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-primary animate-pulse" />
                <p className="text-sm font-medium">
                  AI Engine processing profiles...
                </p>
              </div>
              <Progress value={65} className="h-2 mt-2" />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Suggested Teams */}
      {(isComplete || true) && (
        <Card className="border-border/50">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-primary" />
                <h3 className="font-semibold">Suggested Teams</h3>
              </div>
              <Button size="sm" className="gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Approve All & Notify
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {suggestedTeams.map((team, idx) => (
              <div
                key={team.name}
                className={cn(
                  "p-4 rounded-xl border transition-colors",
                  isComplete
                    ? "border-primary/20 bg-primary/[0.02]"
                    : "border-border/50"
                )}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-sm font-bold text-primary">
                      {String.fromCharCode(65 + idx)}
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm">{team.name}</h4>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <Badge
                          className={cn(
                            "text-[10px]",
                            team.score >= 90
                              ? "bg-emerald-100 text-emerald-700"
                              : "bg-amber-100 text-amber-700"
                          )}
                        >
                          {team.score}% match
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Button variant="ghost" size="sm" className="gap-1 text-xs">
                      <Shuffle className="w-3 h-3" />
                      Shuffle
                    </Button>
                    <Button variant="ghost" size="sm" className="gap-1 text-xs">
                      <ArrowLeftRight className="w-3 h-3" />
                      Swap Member
                    </Button>
                  </div>
                </div>

                <div className="flex items-center gap-2 mb-2">
                  {team.members.map((member) => (
                    <div
                      key={member}
                      className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-muted/50"
                    >
                      <Avatar className="w-5 h-5">
                        <AvatarFallback className="text-[9px] bg-muted font-bold">
                          {member
                            .split(" ")
                            .map((n) => n[0])
                            .join("")
                            .slice(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-xs font-medium">{member}</span>
                    </div>
                  ))}
                </div>

                <div className="flex items-center gap-1.5">
                  <Target className="w-3 h-3 text-emerald-500" />
                  {team.strengths.map((s) => (
                    <Badge
                      key={s}
                      variant="secondary"
                      className="text-[10px]"
                    >
                      {s}
                    </Badge>
                  ))}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
