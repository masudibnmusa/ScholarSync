import { initializeApp, cert, getApps, applicationDefault } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore } from "firebase-admin/firestore";

let appOptions: Record<string, unknown> = {
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
};

if (process.env.FIREBASE_SERVICE_ACCOUNT_KEY) {
  try {
    const serviceAccount = JSON.parse(
      Buffer.from(process.env.FIREBASE_SERVICE_ACCOUNT_KEY, "base64").toString("utf-8")
    );
    appOptions.credential = cert(serviceAccount);
  } catch (e) {
    console.error("[firebase-admin] Failed to parse FIREBASE_SERVICE_ACCOUNT_KEY");
    appOptions.credential = applicationDefault();
  }
} else {
  // Fall back to Application Default Credentials (works on Vercel, Cloud Functions, etc.)
  appOptions.credential = applicationDefault();
}

const adminApp =
  getApps().length === 0 ? initializeApp(appOptions) : getApps()[0];

export const adminAuth = getAuth(adminApp);
export const adminDb = getFirestore(adminApp);

export async function verifyRequest(req: Request) {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) return null;
  const token = authHeader.split("Bearer ")[1];
  try {
    return await adminAuth.verifyIdToken(token);
  } catch {
    return null;
  }
}
