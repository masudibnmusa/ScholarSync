"use client";

import { create } from "zustand";
import { auth } from "@/lib/firebase";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
} from "firebase/auth";

export type UserRole = "student" | "instructor";
export type View =
  | "login"
  | "register"
  | "student-dashboard"
  | "student-chat"
  | "student-tasks"
  | "student-files"
  | "student-notifications"
  | "student-peer-review"
  | "student-profile"
  | "instructor-dashboard"
  | "instructor-teams"
  | "instructor-analytics"
  | "instructor-conflicts"
  | "instructor-matching";

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  timestamp: string;
  isMe: boolean;
  fileName?: string | null;
  fileSize?: string | null;
}

export interface KanbanTask {
  id: string;
  title: string;
  description: string;
  status: "todo" | "in-progress" | "done";
  assigneeId: string | null;
  assigneeName: string;
  priority: "low" | "medium" | "high";
  dueDate: string | null;
}

export interface TeamMember {
  id: string;
  userId: string;
  name: string;
  bio: string;
  skills: string[];
  availability: string;
  contribution: number;
}

export interface Team {
  id: string;
  name: string;
  description: string;
  healthScore: number;
  progress: number;
  members: TeamMember[];
  _count?: { tasks: number; messages: number };
}

export interface Notification {
  id: string;
  type: string;
  title: string;
  description: string;
  read: boolean;
  createdAt: string;
}

export interface FileUpload {
  id: string;
  fileName: string;
  fileSize: number;
  fileType: string;
  uploadedBy: string;
  createdAt: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: string;
  bio: string;
  skills: string[];
  availability: string;
}

export interface ConflictAlert {
  id: string;
  teamId: string;
  teamName: string;
  severity: string;
  description: string;
  sentimentScore: number;
  isResolved: boolean;
  createdAt: string;
}

export interface AppState {
  // Auth
  currentView: View;
  currentUser: UserProfile | null;
  isLoading: boolean;
  error: string | null;

  // Navigation
  selectedTeam: Team | null;
  sidebarCollapsed: boolean;

  // Data
  teams: Team[];
  chatMessages: Record<string, ChatMessage[]>;
  kanbanTasks: KanbanTask[];
  notifications: Notification[];
  files: FileUpload[];
  conflictAlerts: ConflictAlert[];
  showAIModal: boolean;
  unreadNotifCount: number;

  // Actions
  setView: (view: View) => void;
  setLoading: (loading: boolean) => void;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string, role: string) => Promise<boolean>;
  logout: () => void;
  setCurrentUser: (user: UserProfile | null) => void;
  setSelectedTeam: (team: Team | null) => void;
  toggleSidebar: () => void;
  dismissAIModal: () => void;

  // Data fetching
  fetchTeams: () => Promise<void>;
  fetchChatMessages: (teamId: string) => Promise<void>;
  fetchTasks: (teamId: string) => Promise<void>;
  fetchNotifications: () => Promise<void>;
  fetchFiles: (teamId: string) => Promise<void>;
  fetchProfile: () => Promise<void>;
  fetchConflicts: () => Promise<void>;

  // Chat actions
  sendMessage: (teamId: string, content: string, fileName?: string, fileSize?: string) => Promise<void>;

  // Task actions
  createTask: (teamId: string, data: { title: string; description: string; priority: string; dueDate: string; assigneeId: string }) => Promise<void>;
  updateTask: (taskId: string, data: Partial<KanbanTask>) => Promise<void>;
  deleteTask: (taskId: string) => Promise<void>;

  // Notification actions
  markNotificationRead: (id: string) => Promise<void>;
  markAllNotificationsRead: () => Promise<void>;

  // File actions
  uploadFile: (teamId: string, file: File) => Promise<void>;

  // Peer review
  submitPeerReview: (teamId: string, targetId: string, overallRating: number, feedback: string, categoryRatings: Record<string, number>) => Promise<void>;

  // Profile actions
  updateProfile: (data: { bio?: string; skills?: string[]; availability?: string }) => Promise<void>;

  // Conflict actions
  resolveConflict: (id: string) => Promise<void>;
}

// API helper — includes Firebase ID token
async function api(url: string, options?: RequestInit) {
  let token = "";
  try {
    token = (await auth.currentUser?.getIdToken()) || "";
  } catch {
    // ignore — token may not be available
  }

  const res = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    ...options,
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    let message = `Request failed (${res.status})`;
    try {
      const json = JSON.parse(text);
      if (json.error) message = json.error;
    } catch {
      if (text) message = text.substring(0, 200);
    }
    throw new Error(message);
  }
  return res.json();
}

export const useAppStore = create<AppState>((set, get) => ({
  currentView: "login",
  currentUser: null,
  isLoading: false,
  error: null,
  selectedTeam: null,
  sidebarCollapsed: false,
  teams: [],
  chatMessages: {},
  kanbanTasks: [],
  notifications: [],
  files: [],
  conflictAlerts: [],
  showAIModal: false,
  unreadNotifCount: 0,

  setView: (view) => set({ currentView: view }),
  setLoading: (loading) => set({ isLoading: loading }),

  login: async (email, password) => {
    set({ isLoading: true, error: null });
    try {
      const cred = await signInWithEmailAndPassword(
        auth,
        email.trim().toLowerCase(),
        password
      );

      const user = cred.user;
      const idToken = await user.getIdTokenResult();
      const role = idToken.claims?.role as string | undefined;

      // Set basic user info, then fetch full profile
      const basicUser: UserProfile = {
        id: user.uid,
        name: user.displayName || "",
        email: user.email || "",
        role: role || (await api("/api/profile").then((d) => d.profile?.user?.role).catch(() => "student")) || "student",
        bio: "",
        skills: [],
        availability: "",
      };

      // Try to get role from Firestore user doc
      try {
        const profileData = await api("/api/profile");
        if (profileData?.profile?.user) {
          basicUser.name = profileData.profile.user.name || basicUser.name;
          basicUser.role = profileData.profile.user.role || basicUser.role;
        }
      } catch {
        // Profile may not exist yet, use defaults
      }

      set({
        currentUser: basicUser,
        currentView: basicUser.role === "instructor" ? "instructor-dashboard" : "student-dashboard",
        isLoading: false,
      });

      // Background fetches
      get().fetchProfile();
      get().fetchTeams();
      get().fetchNotifications();
      return true;
    } catch (err) {
      const msg = (err as Error)?.message || "Login failed";
      // Map Firebase errors to friendly messages
      let friendlyMsg = msg;
      if (msg.includes("invalid-credential") || msg.includes("INVALID_LOGIN_CREDENTIALS")) {
        friendlyMsg = "Invalid email or password";
      } else if (msg.includes("user-not-found")) {
        friendlyMsg = "No account found with this email";
      } else if (msg.includes("too-many-requests")) {
        friendlyMsg = "Too many attempts. Please try again later.";
      }
      set({ error: friendlyMsg, isLoading: false });
      return false;
    }
  },

  register: async (name, email, password, role) => {
    set({ isLoading: true, error: null });
    try {
      // 1. Create Firebase Auth user
      const cred = await createUserWithEmailAndPassword(
        auth,
        email.trim().toLowerCase(),
        password
      );

      // 2. Update display name
      await cred.user.updateProfile({ displayName: name.trim() });

      // 3. Call /api/register to create Firestore user doc
      let token = "";
      try {
        token = await cred.user.getIdToken();
      } catch {
        // ignore
      }
      try {
        await fetch("/api/register", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({ name: name.trim(), role }),
        });
      } catch {
        // Registration in Firestore may fail, but auth user is created
      }

      const user = cred.user;
      const registeredUser: UserProfile = {
        id: user.uid,
        name: name.trim(),
        email: user.email || "",
        role: role || "student",
        bio: "",
        skills: [],
        availability: "",
      };

      set({
        currentUser: registeredUser,
        currentView: registeredUser.role === "instructor" ? "instructor-dashboard" : "student-dashboard",
        isLoading: false,
      });

      get().fetchTeams();
      get().fetchNotifications();
      return true;
    } catch (err) {
      const msg = (err as Error)?.message || "Registration failed";
      let friendlyMsg = msg;
      if (msg.includes("email-already-in-use")) {
        friendlyMsg = "This email is already registered. Try signing in instead.";
      } else if (msg.includes("weak-password")) {
        friendlyMsg = "Password should be at least 6 characters";
      } else if (msg.includes("invalid-email")) {
        friendlyMsg = "Please enter a valid email address";
      }
      set({ error: friendlyMsg, isLoading: false });
      return false;
    }
  },

  logout: async () => {
    try {
      await signOut(auth);
    } catch {
      // ignore
    }
    set({
      currentUser: null,
      currentView: "login",
      selectedTeam: null,
      teams: [],
      chatMessages: {},
      kanbanTasks: [],
      notifications: [],
      files: [],
      conflictAlerts: [],
    });
  },

  setCurrentUser: (user) => set({ currentUser: user }),

  setSelectedTeam: (team) => {
    set({ selectedTeam: team });
    if (team) {
      get().fetchChatMessages(team.id);
      get().fetchTasks(team.id);
      get().fetchFiles(team.id);
    }
  },

  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  dismissAIModal: () => set({ showAIModal: false }),

  // Data fetching
  fetchTeams: async () => {
    try {
      const data = await api("/api/teams");
      const rawTeams = Array.isArray(data.teams) ? data.teams : Array.isArray(data) ? data : [];
      const teams: Team[] = rawTeams.map((t: Record<string, unknown>) => ({
        id: t.id as string,
        name: t.name as string,
        description: (t.description as string) || "",
        healthScore: (t.healthScore as number) || 0,
        progress: (t.progress as number) || 0,
        members: Array.isArray(t.members)
          ? (t.members as Record<string, unknown>[]).map((m) => ({
              id: m.id as string,
              userId: m.userId as string,
              name: (m.name as string) || "Unknown",
              bio: (m.bio as string) || "",
              skills: Array.isArray(m.skills) ? (m.skills as string[]) : [],
              availability: (m.availability as string) || "",
              contribution: (m.contribution as number) || 0,
            }))
          : [],
        _count: t._count as { tasks: number; messages: number } | undefined,
      }));
      set({ teams });
      if (teams.length > 0 && !get().selectedTeam) {
        get().setSelectedTeam(teams[0]);
      }
    } catch (err) {
      console.error("Failed to fetch teams:", err);
    }
  },

  fetchChatMessages: async (teamId: string) => {
    try {
      const data = await api(`/api/chat/${teamId}`);
      const messages = Array.isArray(data.messages) ? data.messages : Array.isArray(data) ? data : [];
      const user = get().currentUser;
      set((s) => ({
        chatMessages: {
          ...s.chatMessages,
          [teamId]: messages.map((m: Record<string, unknown>) => ({
            id: m.id as string,
            senderId: m.senderId as string,
            senderName: m.senderName as string,
            content: m.content as string,
            timestamp: m.timestamp as string,
            isMe: m.senderId === user?.id,
            fileName: m.fileName as string | null,
            fileSize: m.fileSize as string | null,
          })),
        },
      }));
    } catch (err) {
      console.error("Failed to fetch messages:", err);
    }
  },

  fetchTasks: async (teamId: string) => {
    try {
      const data = await api(`/api/tasks/${teamId}`);
      const tasks = Array.isArray(data.tasks) ? data.tasks : Array.isArray(data) ? data : [];
      set({ kanbanTasks: tasks });
    } catch (err) {
      console.error("Failed to fetch tasks:", err);
    }
  },

  fetchNotifications: async () => {
    try {
      const data = await api("/api/notifications");
      const notifications = Array.isArray(data.notifications) ? data.notifications : Array.isArray(data) ? data : [];
      const unread = notifications.filter((n: Notification) => !n.read).length;
      set({ notifications, unreadNotifCount: unread });
    } catch (err) {
      console.error("Failed to fetch notifications:", err);
    }
  },

  fetchFiles: async (teamId: string) => {
    try {
      const data = await api(`/api/files/${teamId}`);
      const files = Array.isArray(data.files) ? data.files : Array.isArray(data) ? data : [];
      set({ files });
    } catch (err) {
      console.error("Failed to fetch files:", err);
    }
  },

  fetchProfile: async () => {
    try {
      const data = await api("/api/profile");
      const profile = data.profile || data;
      const user = profile.user || profile;
      set({
        currentUser: {
          id: user.id || get().currentUser?.id || "",
          name: user.name || get().currentUser?.name || "",
          email: user.email || get().currentUser?.email || "",
          role: user.role || get().currentUser?.role || "student",
          bio: profile.bio || "",
          skills: profile.skills || [],
          availability: profile.availability || "",
        },
      });
    } catch (err) {
      console.error("Failed to fetch profile:", err);
    }
  },

  fetchConflicts: async () => {
    try {
      const data = await api("/api/conflicts");
      const conflicts = Array.isArray(data.conflicts) ? data.conflicts : Array.isArray(data) ? data : [];
      set({ conflictAlerts: conflicts });
    } catch (err) {
      console.error("Failed to fetch conflicts:", err);
    }
  },

  // Chat — always HTTP (no more socket.io)
  sendMessage: async (teamId, content, fileName, fileSize) => {
    try {
      const user = get().currentUser;
      if (!user) return;

      await api(`/api/chat/${teamId}`, {
        method: "POST",
        body: JSON.stringify({ content, fileName, fileSize }),
      });
      await get().fetchChatMessages(teamId);
    } catch (err) {
      console.error("Failed to send message:", err);
    }
  },

  // Tasks
  createTask: async (teamId, data) => {
    try {
      await api(`/api/tasks/${teamId}`, {
        method: "POST",
        body: JSON.stringify(data),
      });
      await get().fetchTasks(teamId);
    } catch (err) {
      console.error("Failed to create task:", err);
    }
  },

  updateTask: async (taskId, data) => {
    try {
      await api(`/api/tasks/${taskId}`, {
        method: "PUT",
        body: JSON.stringify(data),
      });
      const teamId = get().selectedTeam?.id;
      if (teamId) await get().fetchTasks(teamId);
    } catch (err) {
      console.error("Failed to update task:", err);
    }
  },

  deleteTask: async (taskId) => {
    try {
      await api(`/api/tasks/${taskId}`, { method: "DELETE" });
      const teamId = get().selectedTeam?.id;
      if (teamId) await get().fetchTasks(teamId);
    } catch (err) {
      console.error("Failed to delete task:", err);
    }
  },

  // Notifications
  markNotificationRead: async (id) => {
    try {
      await api(`/api/notifications/${id}`, { method: "PUT" });
      await get().fetchNotifications();
    } catch (err) {
      console.error("Failed to mark notification:", err);
    }
  },

  markAllNotificationsRead: async () => {
    try {
      await api("/api/notifications/read-all", { method: "PUT" });
      await get().fetchNotifications();
    } catch (err) {
      console.error("Failed to mark all notifications:", err);
    }
  },

  // Files
  uploadFile: async (teamId, file) => {
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("teamId", teamId);

      let token = "";
      try {
        token = (await auth.currentUser?.getIdToken()) || "";
      } catch {}

      await fetch("/api/files/upload", {
        method: "POST",
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        body: formData,
      });
      await get().fetchFiles(teamId);
    } catch (err) {
      console.error("Failed to upload file:", err);
    }
  },

  // Peer Review
  submitPeerReview: async (teamId, targetId, overallRating, feedback, categoryRatings) => {
    try {
      await api("/api/peer-review", {
        method: "POST",
        body: JSON.stringify({ teamId, targetId, overallRating, feedback, categoryRatings }),
      });
    } catch (err) {
      console.error("Failed to submit peer review:", err);
    }
  },

  // Profile
  updateProfile: async (data) => {
    try {
      await api("/api/profile", {
        method: "PUT",
        body: JSON.stringify(data),
      });
      await get().fetchProfile();
    } catch (err) {
      console.error("Failed to update profile:", err);
    }
  },

  // Conflicts
  resolveConflict: async (id) => {
    try {
      await api(`/api/conflicts/${id}`, {
        method: "PUT",
        body: JSON.stringify({ isResolved: true }),
      });
      await get().fetchConflicts();
    } catch (err) {
      console.error("Failed to resolve conflict:", err);
    }
  },
}));
