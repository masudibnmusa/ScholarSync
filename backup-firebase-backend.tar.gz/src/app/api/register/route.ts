import { NextRequest, NextResponse } from "next/server";
import { verifyRequest, adminDb } from "@/lib/firebase-admin";

export async function POST(request: NextRequest) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    let body: Record<string, unknown>;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { error: "Invalid request body. Please send JSON data." },
        { status: 400 }
      );
    }

    const { name, role } = body;
    const uid = decoded.uid;
    const email = decoded.email || "";

    if (!name || typeof name !== "string" || name.trim().length === 0) {
      return NextResponse.json({ error: "Name is required" }, { status: 400 });
    }

    const userRef = adminDb.collection("users").doc(uid);
    const existingDoc = await userRef.get();

    if (existingDoc.exists) {
      // Already registered — return 200
      return NextResponse.json({ success: true });
    }

    // Create user doc
    await userRef.set({
      name: (name as string).trim(),
      email,
      role: (role as string) || "student",
      createdAt: new Date().toISOString(),
    });

    // Create profile subcollection doc
    await userRef.collection("profile").doc("main").set({
      bio: "",
      skills: [],
      availability: "",
      updatedAt: new Date().toISOString(),
    });

    return NextResponse.json({ success: true }, { status: 201 });
  } catch (error) {
    console.error("Registration error:", error);
    return NextResponse.json(
      { error: "Registration failed. Please try again." },
      { status: 500 }
    );
  }
}
