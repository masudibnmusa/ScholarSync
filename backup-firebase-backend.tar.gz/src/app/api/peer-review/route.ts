import { NextRequest, NextResponse } from "next/server";
import { verifyRequest, adminDb } from "@/lib/firebase-admin";

export async function POST(request: NextRequest) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = decoded.uid;
    const body = await request.json();
    const { teamId, targetId, overallRating, feedback, categoryRatings } = body;

    if (!teamId || !targetId || overallRating === undefined) {
      return NextResponse.json(
        { error: "teamId, targetId, and overallRating are required" },
        { status: 400 }
      );
    }

    if (userId === targetId) {
      return NextResponse.json(
        { error: "Cannot review yourself" },
        { status: 400 }
      );
    }

    // Verify both reviewer and target are team members
    const [reviewerSnap, targetSnap] = await Promise.all([
      adminDb
        .collection("teamMembers")
        .where("teamId", "==", teamId)
        .where("userId", "==", userId)
        .limit(1)
        .get(),
      adminDb
        .collection("teamMembers")
        .where("teamId", "==", teamId)
        .where("userId", "==", targetId)
        .limit(1)
        .get(),
    ]);

    if (reviewerSnap.empty) {
      return NextResponse.json(
        { error: "You are not a member of this team" },
        { status: 403 }
      );
    }

    if (targetSnap.empty) {
      return NextResponse.json(
        { error: "Target user is not a member of this team" },
        { status: 400 }
      );
    }

    // Check if review already exists (upsert pattern)
    const existingReview = await adminDb
      .collection("peerReviews")
      .where("teamId", "==", teamId)
      .where("reviewerId", "==", userId)
      .where("targetId", "==", targetId)
      .limit(1)
      .get();

    const reviewData = {
      teamId,
      reviewerId: userId,
      targetId,
      overallRating,
      feedback: feedback || "",
      categoryRatings: categoryRatings || {},
      updatedAt: new Date().toISOString(),
    };

    let reviewId: string;
    if (!existingReview.empty) {
      reviewId = existingReview.docs[0].id;
      await adminDb.collection("peerReviews").doc(reviewId).update(reviewData);
    } else {
      reviewData.createdAt = new Date().toISOString();
      const ref = await adminDb.collection("peerReviews").add(reviewData);
      reviewId = ref.id;
    }

    // Fetch reviewer and target names
    const [reviewerDoc, targetDoc] = await Promise.all([
      adminDb.collection("users").doc(userId).get(),
      adminDb.collection("users").doc(targetId).get(),
    ]);

    return NextResponse.json(
      {
        review: {
          id: reviewId,
          ...reviewData,
          reviewer: { id: userId, name: reviewerDoc.data()?.name || "Unknown" },
          target: { id: targetId, name: targetDoc.data()?.name || "Unknown" },
        },
      },
      { status: existingReview.empty ? 201 : 200 }
    );
  } catch (error) {
    console.error("Create peer review error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
