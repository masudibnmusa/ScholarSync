import { NextRequest, NextResponse } from "next/server";
import { verifyRequest, adminDb } from "@/lib/firebase-admin";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ teamId: string }> }
) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { teamId } = await params;
    const userId = decoded.uid;
    const userDoc = await adminDb.collection("users").doc(userId).get();
    const role = (userDoc.data()?.role as string) || "student";

    let reviewsSnap;
    if (role === "instructor") {
      reviewsSnap = await adminDb
        .collection("peerReviews")
        .where("teamId", "==", teamId)
        .orderBy("createdAt", "desc")
        .get();
    } else {
      // Firestore doesn't support OR on different fields in one query,
      // so we do two queries and merge
      const [byReviewer, byTarget] = await Promise.all([
        adminDb
          .collection("peerReviews")
          .where("teamId", "==", teamId)
          .where("reviewerId", "==", userId)
          .get(),
        adminDb
          .collection("peerReviews")
          .where("teamId", "==", teamId)
          .where("targetId", "==", userId)
          .get(),
      ]);
      // Merge and deduplicate
      const map = new Map<string, FirebaseFirestore.QueryDocumentSnapshot>();
      for (const d of byReviewer.docs) map.set(d.id, d);
      for (const d of byTarget.docs) map.set(d.id, d);
      reviewsSnap = { docs: Array.from(map.values()), size: map.size } as FirebaseFirestore.QuerySnapshot;
    }

    // Batch-fetch user names
    const userIds = new Set<string>();
    for (const doc of reviewsSnap.docs) {
      const d = doc.data();
      userIds.add(d.reviewerId as string);
      userIds.add(d.targetId as string);
    }
    const userNames: Record<string, string> = {};
    const userDocs = await Promise.all(
      Array.from(userIds).map((uid) => adminDb.collection("users").doc(uid).get())
    );
    for (let i = 0; i < userDocs.length; i++) {
      const uid = Array.from(userIds)[i];
      userNames[uid] = (userDocs[i].data()?.name as string) || "Unknown";
    }

    const reviews = reviewsSnap.docs.map((doc) => {
      const data = doc.data();
      return {
        id: doc.id,
        teamId: data.teamId,
        reviewerId: data.reviewerId,
        targetId: data.targetId,
        overallRating: data.overallRating,
        feedback: data.feedback || "",
        categoryRatings: data.categoryRatings || {},
        createdAt: data.createdAt,
        reviewer: { id: data.reviewerId, name: userNames[data.reviewerId as string] || "Unknown" },
        target: { id: data.targetId, name: userNames[data.targetId as string] || "Unknown" },
      };
    });

    return NextResponse.json({ reviews });
  } catch (error) {
    console.error("Get peer reviews error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
