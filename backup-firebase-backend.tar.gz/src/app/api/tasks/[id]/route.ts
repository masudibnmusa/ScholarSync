import { NextRequest, NextResponse } from "next/server";
import { verifyRequest, adminDb } from "@/lib/firebase-admin";

// GET /api/tasks/[id] — id is teamId: list tasks for a team
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id: teamId } = await params;
    const userId = decoded.uid;
    const userDoc = await adminDb.collection("users").doc(userId).get();
    const isInstructor = (userDoc.data()?.role as string) === "instructor";

    if (!isInstructor) {
      const memberSnap = await adminDb
        .collection("teamMembers")
        .where("teamId", "==", teamId)
        .where("userId", "==", userId)
        .limit(1)
        .get();
      if (memberSnap.empty) {
        return NextResponse.json({ error: "Not a member of this team" }, { status: 403 });
      }
    }

    const tasksSnap = await adminDb
      .collection("tasks")
      .where("teamId", "==", teamId)
      .orderBy("createdAt", "desc")
      .get();

    // Batch-fetch assignee names
    const assigneeIds = new Set<string>();
    tasksSnap.docs.forEach((d) => {
      const aId = d.data().assigneeId;
      if (aId) assigneeIds.add(aId as string);
    });
    const assigneeNames: Record<string, string> = {};
    if (assigneeIds.size > 0) {
      const userDocs = await Promise.all(
        Array.from(assigneeIds).map((uid) => adminDb.collection("users").doc(uid).get())
      );
      for (let i = 0; i < userDocs.length; i++) {
        const uid = Array.from(assigneeIds)[i];
        assigneeNames[uid] = (userDocs[i].data()?.name as string) || null;
      }
    }

    const tasks = tasksSnap.docs.map((doc) => {
      const data = doc.data();
      return {
        id: doc.id,
        title: data.title,
        description: data.description || "",
        status: data.status,
        priority: data.priority,
        dueDate: data.dueDate || null,
        teamId: data.teamId,
        assigneeId: data.assigneeId || null,
        assigneeName: data.assigneeId ? (assigneeNames[data.assigneeId as string] || null) : null,
        createdAt: data.createdAt,
        updatedAt: data.updatedAt,
      };
    });

    return NextResponse.json({ tasks });
  } catch (error) {
    console.error("Get tasks error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

// POST /api/tasks/[id] — id is teamId: create a task
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id: teamId } = await params;
    const userId = decoded.uid;
    const userDoc = await adminDb.collection("users").doc(userId).get();
    const userName = (userDoc.data()?.name as string) || "Unknown";
    const isInstructor = (userDoc.data()?.role as string) === "instructor";

    if (!isInstructor) {
      const memberSnap = await adminDb
        .collection("teamMembers")
        .where("teamId", "==", teamId)
        .where("userId", "==", userId)
        .limit(1)
        .get();
      if (memberSnap.empty) {
        return NextResponse.json({ error: "Not a member of this team" }, { status: 403 });
      }
    }

    const body = await request.json();
    const { title, description, priority, dueDate, assigneeId } = body;

    if (!title) {
      return NextResponse.json({ error: "Task title is required" }, { status: 400 });
    }

    let assigneeName: string | null = null;
    if (assigneeId) {
      const assigneeDoc = await adminDb.collection("users").doc(assigneeId).get();
      assigneeName = assigneeDoc.data()?.name || null;
    }

    const now = new Date().toISOString();
    const taskRef = await adminDb.collection("tasks").add({
      teamId,
      title,
      description: description || "",
      status: "todo",
      priority: priority || "medium",
      dueDate: dueDate || null,
      assigneeId: assigneeId || null,
      assigneeName,
      createdAt: now,
      updatedAt: now,
    });

    // Create notification for assignee
    if (assigneeId && assigneeId !== userId) {
      await adminDb.collection("notifications").add({
        userId: assigneeId,
        type: "task_assigned",
        title: "New task assigned",
        description: `${userName} assigned you a task: ${title}`,
        read: false,
        createdAt: new Date().toISOString(),
      });
    }

    return NextResponse.json(
      {
        task: {
          id: taskRef.id,
          teamId,
          title,
          description: description || "",
          status: "todo",
          priority: priority || "medium",
          dueDate: dueDate || null,
          assigneeId: assigneeId || null,
          createdAt: now,
          updatedAt: now,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Create task error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

// PUT /api/tasks/[id] — id is taskId: update a task
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id: taskId } = await params;

    const taskDoc = await adminDb.collection("tasks").doc(taskId).get();
    if (!taskDoc.exists) {
      return NextResponse.json({ error: "Task not found" }, { status: 404 });
    }

    const body = await request.json();
    const { status, title, description, priority, dueDate, assigneeId } = body;

    const updates: Record<string, unknown> = { updatedAt: new Date().toISOString() };
    if (status !== undefined) updates.status = status;
    if (title !== undefined) updates.title = title;
    if (description !== undefined) updates.description = description;
    if (priority !== undefined) updates.priority = priority;
    if (dueDate !== undefined) updates.dueDate = dueDate;
    if (assigneeId !== undefined) updates.assigneeId = assigneeId;

    // Resolve assignee name if assigneeId changed
    if (assigneeId) {
      const assigneeDoc = await adminDb.collection("users").doc(assigneeId).get();
      updates.assigneeName = assigneeDoc.data()?.name || null;
    }

    await adminDb.collection("tasks").doc(taskId).update(updates);

    const updated = (await adminDb.collection("tasks").doc(taskId).get()).data();

    return NextResponse.json({
      task: {
        id: taskId,
        title: updated?.title,
        description: updated?.description,
        status: updated?.status,
        priority: updated?.priority,
        dueDate: updated?.dueDate,
        teamId: updated?.teamId,
        assigneeId: updated?.assigneeId,
        assigneeName: updated?.assigneeName || null,
        createdAt: updated?.createdAt,
        updatedAt: updated?.updatedAt,
      },
    });
  } catch (error) {
    console.error("Update task error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

// DELETE /api/tasks/[id] — id is taskId: delete a task
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id: taskId } = await params;
    const userId = decoded.uid;

    const taskDoc = await adminDb.collection("tasks").doc(taskId).get();
    if (!taskDoc.exists) {
      return NextResponse.json({ error: "Task not found" }, { status: 404 });
    }

    const taskData = taskDoc.data()!;

    // Only assignee or team creator can delete
    if (taskData.assigneeId !== userId) {
      const teamDoc = await adminDb.collection("teams").doc(taskData.teamId as string).get();
      const teamData = teamDoc.data();
      if (!teamDoc.exists || teamData?.createdBy !== userId) {
        return NextResponse.json(
          { error: "Only the assignee or team creator can delete this task" },
          { status: 403 }
        );
      }
    }

    await adminDb.collection("tasks").doc(taskId).delete();
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Delete task error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
