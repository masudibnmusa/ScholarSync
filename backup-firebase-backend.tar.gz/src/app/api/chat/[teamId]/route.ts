import { NextRequest, NextResponse } from "next/server";
import { verifyRequest, adminDb } from "@/lib/firebase-admin";

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ teamId: string }> }
) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { teamId } = await params;
    const userId = decoded.uid;
    const userDoc = await adminDb.collection("users").doc(userId).get();
    const isInstructor = (userDoc.data()?.role as string) === "instructor";

    if (!isInstructor) {
      // Check membership
      const memberSnap = await adminDb
        .collection("teamMembers")
        .where("teamId", "==", teamId)
        .where("userId", "==", userId)
        .limit(1)
        .get();
      if (memberSnap.empty) {
        return NextResponse.json({ error: "Not a member of this team" }, { status: 403 });
      }
    }

    const messagesSnap = await adminDb
      .collection("messages")
      .where("teamId", "==", teamId)
      .orderBy("timestamp", "asc")
      .get();

    // Batch-fetch sender names
    const senderIds = new Set<string>();
    messagesSnap.docs.forEach((d) => senderIds.add(d.data().senderId as string));
    const senderNames: Record<string, string> = {};
    if (senderIds.size > 0) {
      const userDocs = await Promise.all(
        Array.from(senderIds).map((uid) => adminDb.collection("users").doc(uid).get())
      );
      for (let i = 0; i < userDocs.length; i++) {
        const uid = Array.from(senderIds)[i];
        senderNames[uid] = (userDocs[i].data()?.name as string) || "Unknown";
      }
    }

    const messages = messagesSnap.docs.map((doc) => {
      const data = doc.data();
      const sName = data.senderName || senderNames[data.senderId as string] || "Unknown";
      return {
        id: doc.id,
        content: data.content,
        teamId: data.teamId,
        senderId: data.senderId,
        timestamp: data.timestamp,
        fileName: data.fileName || null,
        fileSize: data.fileSize || null,
        senderName: sName,
        senderAvatar: getInitials(sName),
      };
    });

    return NextResponse.json({ messages });
  } catch (error) {
    console.error("Get messages error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ teamId: string }> }
) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { teamId } = await params;
    const userId = decoded.uid;
    const userDoc = await adminDb.collection("users").doc(userId).get();
    const userData = userDoc.data();
    const userName = (userData?.name as string) || "Unknown";
    const isInstructor = (userData?.role as string) === "instructor";

    if (!isInstructor) {
      const memberSnap = await adminDb
        .collection("teamMembers")
        .where("teamId", "==", teamId)
        .where("userId", "==", userId)
        .limit(1)
        .get();
      if (memberSnap.empty) {
        return NextResponse.json({ error: "Not a member of this team" }, { status: 403 });
      }
    }

    const body = await request.json();
    const { content, fileName, fileSize } = body;

    if (!content) {
      return NextResponse.json({ error: "Message content is required" }, { status: 400 });
    }

    const timestamp = new Date().toISOString();
    const msgRef = await adminDb.collection("messages").add({
      teamId,
      senderId: userId,
      senderName: userName,
      content,
      timestamp,
      fileName: fileName || null,
      fileSize: fileSize || null,
    });

    // Auto-create notifications for mentioned users (@name)
    const mentionPattern = /@(\w+)/g;
    let match: RegExpExecArray | null;
    const mentionedNames = new Set<string>();

    while ((match = mentionPattern.exec(content)) !== null) {
      mentionedNames.add(match[1]);
    }

    if (mentionedNames.size > 0) {
      const teamMembersSnap = await adminDb
        .collection("teamMembers")
        .where("teamId", "==", teamId)
        .get();

      const memberUserIds = teamMembersSnap.docs.map((d) => d.data().userId as string);
      const memberUserDocs = await Promise.all(
        memberUserIds.map((uid) => adminDb.collection("users").doc(uid).get())
      );

      for (const name of mentionedNames) {
        for (let i = 0; i < memberUserDocs.length; i++) {
          const mName = (memberUserDocs[i].data()?.name as string) || "";
          if (
            mName.toLowerCase().includes(name.toLowerCase()) &&
            memberUserIds[i] !== userId
          ) {
            await adminDb.collection("notifications").add({
              userId: memberUserIds[i],
              type: "mention",
              title: "You were mentioned",
              description: `${userName} mentioned you in a message: ${content.slice(0, 100)}`,
              read: false,
              createdAt: new Date().toISOString(),
            });
            break;
          }
        }
      }
    }

    return NextResponse.json(
      {
        message: {
          id: msgRef.id,
          content,
          teamId,
          senderId: userId,
          timestamp,
          fileName: fileName || null,
          fileSize: fileSize || null,
          senderName: userName,
          senderAvatar: getInitials(userName),
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Create message error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
