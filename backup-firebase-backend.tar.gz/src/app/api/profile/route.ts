import { NextRequest, NextResponse } from "next/server";
import { verifyRequest, adminDb } from "@/lib/firebase-admin";

export async function GET(request: NextRequest) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = decoded.uid;

    const userDoc = await adminDb.collection("users").doc(userId).get();
    if (!userDoc.exists) {
      return NextResponse.json({ error: "Profile not found" }, { status: 404 });
    }

    const profileDoc = await adminDb
      .collection("users")
      .doc(userId)
      .collection("profile")
      .doc("main")
      .get();

    const userData = userDoc.data()!;
    const profileData = profileDoc.exists ? profileDoc.data() : { bio: "", skills: [], availability: "" };

    return NextResponse.json({
      profile: {
        user: {
          id: userId,
          name: userData.name,
          email: userData.email,
          role: userData.role,
          createdAt: userData.createdAt,
        },
        bio: profileData.bio || "",
        skills: Array.isArray(profileData.skills) ? profileData.skills : [],
        availability: profileData.availability || "",
      },
    });
  } catch (error) {
    console.error("Get profile error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = decoded.uid;
    const body = await request.json();
    const { bio, skills, availability } = body;

    const profileRef = adminDb
      .collection("users")
      .doc(userId)
      .collection("profile")
      .doc("main");

    const updates: Record<string, unknown> = { updatedAt: new Date().toISOString() };
    if (bio !== undefined) updates.bio = bio;
    if (skills !== undefined) updates.skills = skills; // arrays stored directly in Firestore
    if (availability !== undefined) updates.availability = availability;

    // Upsert: set with merge
    await profileRef.set(updates, { merge: true });

    const updated = (await profileRef.get()).data();

    return NextResponse.json({
      profile: {
        bio: updated?.bio || "",
        skills: Array.isArray(updated?.skills) ? updated.skills : [],
        availability: updated?.availability || "",
      },
    });
  } catch (error) {
    console.error("Update profile error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
