import { NextRequest, NextResponse } from "next/server";
import { verifyRequest, adminDb } from "@/lib/firebase-admin";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ teamId: string }> }
) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { teamId } = await params;
    const userId = decoded.uid;
    const userDoc = await adminDb.collection("users").doc(userId).get();
    const isInstructor = (userDoc.data()?.role as string) === "instructor";

    if (!isInstructor) {
      const memberSnap = await adminDb
        .collection("teamMembers")
        .where("teamId", "==", teamId)
        .where("userId", "==", userId)
        .limit(1)
        .get();
      if (memberSnap.empty) {
        return NextResponse.json(
          { error: "Not a member of this team" },
          { status: 403 }
        );
      }
    }

    const filesSnap = await adminDb
      .collection("fileUploads")
      .where("teamId", "==", teamId)
      .orderBy("createdAt", "desc")
      .get();

    const files = filesSnap.docs.map((doc) => ({
      id: doc.id,
      ...(doc.data()),
    }));

    return NextResponse.json({ files });
  } catch (error) {
    console.error("Get files error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
