import { NextRequest, NextResponse } from "next/server";
import { verifyRequest, adminDb } from "@/lib/firebase-admin";

export async function GET(request: NextRequest) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = decoded.uid;
    const role = decoded.role as string | undefined;
    const userRoles = decoded.customClaims?.role as string | undefined;
    const effectiveRole = userRoles || role || "student";

    if (effectiveRole === "instructor") {
      // Get all teams
      const teamsSnap = await adminDb.collection("teams").orderBy("createdAt", "desc").get();
      const teamIds = teamsSnap.docs.map((d) => d.id);

      // Batch-fetch all team members for these teams
      const membersMap: Record<string, Record<string, unknown>[]> = {};
      if (teamIds.length > 0) {
        // Firestore 'in' queries support max 30 items
        const chunks: string[][] = [];
        for (let i = 0; i < teamIds.length; i += 30) {
          chunks.push(teamIds.slice(i, i + 30));
        }
        const memberSnaps = await Promise.all(
          chunks.map((chunk) => adminDb.collection("teamMembers").where("teamId", "in", chunk).get())
        );
        for (const snap of memberSnaps) {
          for (const doc of snap.docs) {
            const data = doc.data();
            const tid = data.teamId as string;
            if (!membersMap[tid]) membersMap[tid] = [];
            membersMap[tid].push({ id: doc.id, ...data });
          }
        }
      }

      // Collect unique userIds and fetch user docs + profiles
      const allUserIds = new Set<string>();
      for (const members of Object.values(membersMap)) {
        for (const m of members) {
          allUserIds.add(m.userId as string);
        }
      }
      const usersMap: Record<string, Record<string, unknown>> = {};
      if (allUserIds.size > 0) {
        const userIdArr = Array.from(allUserIds);
        const userChunks: string[][] = [];
        for (let i = 0; i < userIdArr.length; i += 30) {
          userChunks.push(userIdArr.slice(i, i + 30));
        }
        // Firestore doesn't support 'in' on document IDs, fetch individually
        const userDocs = await Promise.all(
          userIdArr.map((uid) => adminDb.collection("users").doc(uid).get())
        );
        const profileDocs = await Promise.all(
          userIdArr.map((uid) => adminDb.collection("users").doc(uid).collection("profile").doc("main").get())
        );
        for (let i = 0; i < userIdArr.length; i++) {
          const uData = userDocs[i].data();
          const pData = profileDocs[i].data();
          if (uData) {
            usersMap[userIdArr[i]] = { ...uData, profile: pData || { bio: "", skills: [], availability: "" } };
          }
        }
      }

      // Batch-fetch tasks for each team for progress calculation
      const tasksMap: Record<string, { status: string }[]> = {};
      const taskSnaps = await Promise.all(
        teamIds.map((tid) => adminDb.collection("tasks").where("teamId", "==", tid).get())
      );
      for (let i = 0; i < teamIds.length; i++) {
        tasksMap[teamIds[i]] = taskSnaps[i].docs.map((d) => d.data() as { status: string });
      }

      const teamsWithStats = await Promise.all(
        teamsSnap.docs.map(async (teamDoc) => {
          const team = teamDoc.data();
          const tid = teamDoc.id;
          const members = membersMap[tid] || [];
          const tasks = tasksMap[tid] || [];
          const totalTasks = tasks.length;
          const doneTasks = tasks.filter((t) => t.status === "done").length;
          const progress = totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0;
          const avgContribution =
            members.length > 0
              ? Math.round(members.reduce((sum, m) => sum + ((m.contribution as number) || 0), 0) / members.length)
              : 0;

          const membersWithUser = members.map((m) => {
            const u = usersMap[m.userId as string] || {};
            const p = (u.profile as Record<string, unknown>) || {};
            return {
              id: m.id,
              userId: m.userId,
              name: (u.name as string) || "Unknown",
              bio: (p.bio as string) || "",
              skills: Array.isArray(p.skills) ? (p.skills as string[]) : [],
              availability: (p.availability as string) || "",
              contribution: (m.contribution as number) || 0,
            };
          });

          return {
            id: tid,
            name: team.name,
            description: team.description || "",
            healthScore: avgContribution,
            progress,
            members: membersWithUser,
            _count: { tasks: totalTasks, messages: 0 },
          };
        })
      );

      return NextResponse.json({ teams: teamsWithStats });
    }

    // Student: return teams where user is a member
    const memberSnaps = await adminDb
      .collection("teamMembers")
      .where("userId", "==", userId)
      .get();

    const teamIds = memberSnaps.docs.map((d) => (d.data().teamId as string));

    if (teamIds.length === 0) {
      return NextResponse.json({ teams: [] });
    }

    // Fetch teams
    const teamSnaps = await Promise.all(teamIds.map((tid) => adminDb.collection("teams").doc(tid).get()));
    const teams: { id: string; data: Record<string, unknown> }[] = [];
    for (let i = 0; i < teamIds.length; i++) {
      if (teamSnaps[i].exists) {
        teams.push({ id: teamIds[i], data: teamSnaps[i].data() as Record<string, unknown> });
      }
    }

    // Batch-fetch all members for these teams
    const membersMap: Record<string, Record<string, unknown>[]> = {};
    const memberChunks: string[][] = [];
    for (let i = 0; i < teamIds.length; i += 30) {
      memberChunks.push(teamIds.slice(i, i + 30));
    }
    const allMemberSnaps = await Promise.all(
      memberChunks.map((chunk) => adminDb.collection("teamMembers").where("teamId", "in", chunk).get())
    );
    for (const snap of allMemberSnaps) {
      for (const doc of snap.docs) {
        const data = doc.data();
        const tid = data.teamId as string;
        if (!membersMap[tid]) membersMap[tid] = [];
        membersMap[tid].push({ id: doc.id, ...data });
      }
    }

    // Fetch user docs + profiles
    const allUserIds = new Set<string>();
    for (const members of Object.values(membersMap)) {
      for (const m of members) {
        allUserIds.add(m.userId as string);
      }
    }
    const usersMap: Record<string, Record<string, unknown>> = {};
    if (allUserIds.size > 0) {
      const userIdArr = Array.from(allUserIds);
      const userDocs = await Promise.all(
        userIdArr.map((uid) => adminDb.collection("users").doc(uid).get())
      );
      const profileDocs = await Promise.all(
        userIdArr.map((uid) => adminDb.collection("users").doc(uid).collection("profile").doc("main").get())
      );
      for (let i = 0; i < userIdArr.length; i++) {
        const uData = userDocs[i].data();
        const pData = profileDocs[i].data();
        if (uData) {
          usersMap[userIdArr[i]] = { ...uData, profile: pData || { bio: "", skills: [], availability: "" } };
        }
      }
    }

    // Fetch tasks per team
    const tasksMap: Record<string, { status: string }[]> = {};
    const taskSnaps = await Promise.all(
      teamIds.map((tid) => adminDb.collection("tasks").where("teamId", "==", tid).get())
    );
    for (let i = 0; i < teamIds.length; i++) {
      tasksMap[teamIds[i]] = taskSnaps[i].docs.map((d) => d.data() as { status: string });
    }

    // Fetch message counts per team
    const msgCountMap: Record<string, number> = {};
    const msgSnaps = await Promise.all(
      teamIds.map((tid) => adminDb.collection("messages").where("teamId", "==", tid).get())
    );
    for (let i = 0; i < teamIds.length; i++) {
      msgCountMap[teamIds[i]] = msgSnaps[i].size;
    }

    const teamsWithStats = teams.map(({ id: tid, data: team }) => {
      const members = membersMap[tid] || [];
      const tasks = tasksMap[tid] || [];
      const totalTasks = tasks.length;
      const doneTasks = tasks.filter((t) => t.status === "done").length;
      const progress = totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0;
      const avgContribution =
        members.length > 0
          ? Math.round(members.reduce((sum, m) => sum + ((m.contribution as number) || 0), 0) / members.length)
          : 0;

      const membersWithUser = members.map((m) => {
        const u = usersMap[m.userId as string] || {};
        const p = (u.profile as Record<string, unknown>) || {};
        return {
          id: m.id,
          userId: m.userId,
          name: (u.name as string) || "Unknown",
          bio: (p.bio as string) || "",
          skills: Array.isArray(p.skills) ? (p.skills as string[]) : [],
          availability: (p.availability as string) || "",
          contribution: (m.contribution as number) || 0,
        };
      });

      return {
        id: tid,
        name: team.name,
        description: team.description || "",
        healthScore: avgContribution,
        progress,
        members: membersWithUser,
        _count: { tasks: totalTasks, messages: msgCountMap[tid] || 0 },
      };
    });

    return NextResponse.json({ teams: teamsWithStats });
  } catch (error) {
    console.error("Get teams error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userDoc = await adminDb.collection("users").doc(decoded.uid).get();
    const userRole = (userDoc.data()?.role as string) || "student";

    if (userRole !== "instructor") {
      return NextResponse.json(
        { error: "Only instructors can create teams" },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { name, description, memberIds } = body;

    if (!name) {
      return NextResponse.json({ error: "Team name is required" }, { status: 400 });
    }

    const teamRef = await adminDb.collection("teams").add({
      name,
      description: description || "",
      createdBy: decoded.uid,
      createdAt: new Date().toISOString(),
    });
    const teamId = teamRef.id;

    // Create team member docs
    if (Array.isArray(memberIds) && memberIds.length > 0) {
      await Promise.all(
        memberIds.map((mid: string) =>
          adminDb.collection("teamMembers").add({
            teamId,
            userId: mid,
            joinedAt: new Date().toISOString(),
            contribution: 0,
          })
        )
      );
    }

    return NextResponse.json({ team: { id: teamId, name, description: description || "" } }, { status: 201 });
  } catch (error) {
    console.error("Create team error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
