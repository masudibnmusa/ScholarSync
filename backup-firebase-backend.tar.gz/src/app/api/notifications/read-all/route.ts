import { NextRequest, NextResponse } from "next/server";
import { verifyRequest, adminDb } from "@/lib/firebase-admin";

export async function PUT(request: NextRequest) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = decoded.uid;

    // Firestore doesn't support updateMany, so we query and batch update
    const unreadSnap = await adminDb
      .collection("notifications")
      .where("userId", "==", userId)
      .where("read", "==", false)
      .get();

    if (unreadSnap.empty) {
      return NextResponse.json({ success: true });
    }

    // Use Firestore batch write (max 500 ops per batch)
    let batch = adminDb.batch();
    let count = 0;
    for (const doc of unreadSnap.docs) {
      batch.update(doc.ref, { read: true });
      count++;
      if (count % 500 === 0) {
        await batch.commit();
        batch = adminDb.batch();
      }
    }
    if (count % 500 !== 0) {
      await batch.commit();
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Mark all notifications read error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
