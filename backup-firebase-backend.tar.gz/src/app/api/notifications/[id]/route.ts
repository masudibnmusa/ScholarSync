import { NextRequest, NextResponse } from "next/server";
import { verifyRequest, adminDb } from "@/lib/firebase-admin";

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const userId = decoded.uid;

    const notifDoc = await adminDb.collection("notifications").doc(id).get();
    if (!notifDoc.exists) {
      return NextResponse.json(
        { error: "Notification not found" },
        { status: 404 }
      );
    }

    if (notifDoc.data()?.userId !== userId) {
      return NextResponse.json(
        { error: "Cannot access this notification" },
        { status: 403 }
      );
    }

    await adminDb.collection("notifications").doc(id).update({ read: true });

    const updated = (await adminDb.collection("notifications").doc(id).get()).data();

    return NextResponse.json({ notification: { id, ...updated } });
  } catch (error) {
    console.error("Mark notification read error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
