import { NextRequest, NextResponse } from "next/server";
import { verifyRequest, adminDb } from "@/lib/firebase-admin";

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userDoc = await adminDb.collection("users").doc(decoded.uid).get();
    const role = (userDoc.data()?.role as string) || "student";
    if (role !== "instructor") {
      return NextResponse.json(
        { error: "Only instructors can resolve conflicts" },
        { status: 403 }
      );
    }

    const { id } = await params;

    const conflictDoc = await adminDb.collection("conflictAlerts").doc(id).get();
    if (!conflictDoc.exists) {
      return NextResponse.json(
        { error: "Conflict alert not found" },
        { status: 404 }
      );
    }

    await adminDb.collection("conflictAlerts").doc(id).update({ isResolved: true });

    const updated = (await adminDb.collection("conflictAlerts").doc(id).get()).data();

    return NextResponse.json({ conflict: { id, ...updated } });
  } catch (error) {
    console.error("Resolve conflict error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
