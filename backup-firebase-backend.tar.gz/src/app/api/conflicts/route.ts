import { NextRequest, NextResponse } from "next/server";
import { verifyRequest, adminDb } from "@/lib/firebase-admin";

export async function GET(request: NextRequest) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userDoc = await adminDb.collection("users").doc(decoded.uid).get();
    const role = (userDoc.data()?.role as string) || "student";
    if (role !== "instructor") {
      return NextResponse.json(
        { error: "Only instructors can access conflict alerts" },
        { status: 403 }
      );
    }

    const conflictsSnap = await adminDb
      .collection("conflictAlerts")
      .where("isResolved", "==", false)
      .orderBy("createdAt", "desc")
      .get();

    // Batch-fetch team names
    const teamIds = new Set<string>();
    conflictsSnap.docs.forEach((d) => teamIds.add(d.data().teamId as string));
    const teamNames: Record<string, string> = {};
    if (teamIds.size > 0) {
      const teamDocs = await Promise.all(
        Array.from(teamIds).map((tid) => adminDb.collection("teams").doc(tid).get())
      );
      for (let i = 0; i < teamDocs.length; i++) {
        const tid = Array.from(teamIds)[i];
        teamNames[tid] = (teamDocs[i].data()?.name as string) || "Unknown Team";
      }
    }

    const conflicts = conflictsSnap.docs.map((doc) => {
      const data = doc.data();
      return {
        id: doc.id,
        teamId: data.teamId,
        teamName: teamNames[data.teamId as string] || "Unknown Team",
        severity: data.severity,
        description: data.description,
        sentimentScore: data.sentimentScore,
        isResolved: data.isResolved,
        createdAt: data.createdAt,
      };
    });

    return NextResponse.json({ conflicts });
  } catch (error) {
    console.error("Get conflicts error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
