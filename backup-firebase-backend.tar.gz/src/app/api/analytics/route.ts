import { NextRequest, NextResponse } from "next/server";
import { verifyRequest, adminDb } from "@/lib/firebase-admin";

export async function GET(request: NextRequest) {
  try {
    const decoded = await verifyRequest(request);
    if (!decoded) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userDoc = await adminDb.collection("users").doc(decoded.uid).get();
    const role = (userDoc.data()?.role as string) || "student";
    if (role !== "instructor") {
      return NextResponse.json(
        { error: "Only instructors can access analytics" },
        { status: 403 }
      );
    }

    // Fetch all teams
    const teamsSnap = await adminDb.collection("teams").orderBy("createdAt", "desc").get();
    const teamIds = teamsSnap.docs.map((d) => d.id);

    if (teamIds.length === 0) {
      return NextResponse.json({
        analytics: {
          teams: [],
          overview: { totalTeams: 0, totalStudents: 0, totalTasks: 0, completedTasks: 0, overallProgress: 0 },
        },
      });
    }

    // Fetch all team members
    const allMembers: { id: string; teamId: string; userId: string; contribution: number }[] = [];
    const memberChunks: string[][] = [];
    for (let i = 0; i < teamIds.length; i += 30) {
      memberChunks.push(teamIds.slice(i, i + 30));
    }
    const memberSnaps = await Promise.all(
      memberChunks.map((chunk) => adminDb.collection("teamMembers").where("teamId", "in", chunk).get())
    );
    for (const snap of memberSnaps) {
      for (const doc of snap.docs) {
        const d = doc.data();
        allMembers.push({
          id: doc.id,
          teamId: d.teamId as string,
          userId: d.userId as string,
          contribution: (d.contribution as number) || 0,
        });
      }
    }

    // Fetch all tasks
    const allTasks: { id: string; teamId: string; status: string; assigneeId: string }[] = [];
    const taskSnaps = await Promise.all(
      teamIds.map((tid) => adminDb.collection("tasks").where("teamId", "==", tid).get())
    );
    for (let i = 0; i < teamIds.length; i++) {
      for (const doc of taskSnaps[i].docs) {
        const d = doc.data();
        allTasks.push({
          id: doc.id,
          teamId: teamIds[i],
          status: d.status as string,
          assigneeId: (d.assigneeId as string) || "",
        });
      }
    }

    // Fetch all messages (for participation)
    const allMessages: { teamId: string; senderId: string }[] = [];
    const msgSnaps = await Promise.all(
      teamIds.map((tid) => adminDb.collection("messages").where("teamId", "==", tid).get())
    );
    for (let i = 0; i < teamIds.length; i++) {
      for (const doc of msgSnaps[i].docs) {
        const d = doc.data();
        allMessages.push({ teamId: teamIds[i], senderId: d.senderId as string });
      }
    }

    // Fetch user docs for names and roles
    const allUserIds = new Set<string>();
    allMembers.forEach((m) => allUserIds.add(m.userId));
    const usersMap: Record<string, { name: string; role: string }> = {};
    const userDocs = await Promise.all(
      Array.from(allUserIds).map((uid) => adminDb.collection("users").doc(uid).get())
    );
    for (let i = 0; i < userDocs.length; i++) {
      const uid = Array.from(allUserIds)[i];
      const d = userDocs[i].data();
      if (d) {
        usersMap[uid] = { name: (d.name as string) || "Unknown", role: (d.role as string) || "student" };
      }
    }

    // Build analytics per team
    const teamsAnalytics = teamsSnap.docs.map((teamDoc) => {
      const teamData = teamDoc.data();
      const tid = teamDoc.id;
      const members = allMembers.filter((m) => m.teamId === tid);
      const tasks = allTasks.filter((t) => t.teamId === tid);
      const messages = allMessages.filter((m) => m.teamId === tid);

      const totalTasks = tasks.length;
      const doneTasks = tasks.filter((t) => t.status === "done").length;
      const progress = totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0;
      const avgContribution =
        members.length > 0
          ? Math.round(members.reduce((sum, m) => sum + m.contribution, 0) / members.length)
          : 0;

      // Message count per member
      const messageCountMap: Record<string, number> = {};
      messages.forEach((msg) => {
        messageCountMap[msg.senderId] = (messageCountMap[msg.senderId] || 0) + 1;
      });

      const participationDistribution = members.map((m) => ({
        userId: m.userId,
        userName: usersMap[m.userId]?.name || "Unknown",
        messageCount: messageCountMap[m.userId] || 0,
        contribution: m.contribution,
      }));

      // Task completion per member
      const taskCompletionMap: Record<string, { assigned: number; done: number }> = {};
      members.forEach((m) => {
        taskCompletionMap[m.userId] = { assigned: 0, done: 0 };
      });
      tasks.forEach((t) => {
        if (t.assigneeId && taskCompletionMap[t.assigneeId]) {
          taskCompletionMap[t.assigneeId].assigned++;
          if (t.status === "done") {
            taskCompletionMap[t.assigneeId].done++;
          }
        }
      });

      const memberContributions = members.map((m) => ({
        userId: m.userId,
        userName: usersMap[m.userId]?.name || "Unknown",
        contribution: m.contribution,
        tasksAssigned: taskCompletionMap[m.userId]?.assigned || 0,
        tasksCompleted: taskCompletionMap[m.userId]?.done || 0,
        messagesSent: messageCountMap[m.userId] || 0,
      }));

      return {
        id: tid,
        name: teamData.name,
        description: teamData.description || "",
        healthScore: avgContribution,
        progress,
        totalTasks,
        doneTasks,
        totalMessages: messages.length,
        memberCount: members.length,
        participationDistribution,
        memberContributions,
        createdAt: teamData.createdAt,
      };
    });

    // Overall stats
    const totalStudents = allMembers.filter(
      (m) => usersMap[m.userId]?.role === "student"
    ).length;
    const totalTasksAll = allTasks.length;
    const doneTasksAll = allTasks.filter((t) => t.status === "done").length;

    return NextResponse.json({
      analytics: {
        teams: teamsAnalytics,
        overview: {
          totalTeams: teamsSnap.size,
          totalStudents,
          totalTasks: totalTasksAll,
          completedTasks: doneTasksAll,
          overallProgress:
            totalTasksAll > 0 ? Math.round((doneTasksAll / totalTasksAll) * 100) : 0,
        },
      },
    });
  } catch (error) {
    console.error("Get analytics error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
