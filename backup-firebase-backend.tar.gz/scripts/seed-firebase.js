/**
 * seed-firebase.js — Seeds Firestore with test data using Firebase Admin SDK.
 * Run: node scripts/seed-firebase.js
 * Requires: FIREBASE_SERVICE_ACCOUNT_KEY env var (base64-encoded service account JSON)
 * All accounts use password: password123
 */

const { initializeApp, cert, getApps } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

// Initialize Firebase Admin
let serviceAccount;
if (process.env.FIREBASE_SERVICE_ACCOUNT_KEY) {
  try {
    serviceAccount = JSON.parse(
      Buffer.from(process.env.FIREBASE_SERVICE_ACCOUNT_KEY, "base64").toString("utf-8")
    );
  } catch (e) {
    console.error("Failed to parse FIREBASE_SERVICE_ACCOUNT_KEY");
    process.exit(1);
  }
} else {
  console.error("Missing FIREBASE_SERVICE_ACCOUNT_KEY environment variable");
  console.error('Set it with: export FIREBASE_SERVICE_ACCOUNT_KEY=$(cat service-account-key.json | base64 -w 0)');
  process.exit(1);
}

const adminApp = getApps().length === 0
  ? initializeApp({ credential: cert(serviceAccount) })
  : getApps()[0];

const adminAuth = getAuth(adminApp);
const adminDb = getFirestore(adminApp);

const USERS = [
  { name: "Md. Selim Reja", email: "selim.reja@university.edu", role: "instructor" },
  { name: "Masud Ibn Musa", email: "masud@university.edu", role: "student" },
  { name: "Md Nazmul Hasan", email: "nazmul@university.edu", role: "student" },
  { name: "Chinmoy Kumar", email: "chinmoy@university.edu", role: "student" },
  { name: "Rahim Uddin", email: "rahim@university.edu", role: "student" },
  { name: "Fatima Akter", email: "fatima@university.edu", role: "student" },
  { name: "Kamal Hossain", email: "kamal@university.edu", role: "student" },
  { name: "Sara Islam", email: "sara@university.edu", role: "student" },
  { name: "Tanvir Ahmed", email: "tanvir@university.edu", role: "student" },
  { name: "Nusrat Jahan", email: "nusrat@university.edu", role: "student" },
  {
    name: "Md Nazmul Hasan (DIU)",
    email: "nazmul242-35-859@diu.edu.bd",
    role: "student",
    bio: "Computer Science student at DIU",
    skills: ["React", "Next.js", "Python", "TypeScript"],
    availability: "Full-time",
  },
];

async function seed() {
  console.log("Seeding Firestore with Firebase Admin SDK...\n");

  const PASSWORD = "password123";
  const createdUsers = [];

  // 1. Create Firebase Auth users + Firestore user docs
  for (const u of USERS) {
    let uid;
    try {
      // Check if user already exists
      try {
        const existingUser = await adminAuth.getUserByEmail(u.email);
        uid = existingUser.uid;
        console.log(`  ~ ${u.email} (already exists, uid: ${uid.slice(0, 8)}...)`);
      } catch {
        // User doesn't exist, create
        const userRecord = await adminAuth.createUser({
          email: u.email,
          password: PASSWORD,
          displayName: u.name,
        });
        uid = userRecord.uid;
        console.log(`  + ${u.email} (${u.role}, uid: ${uid.slice(0, 8)}...)`);
      }

      // Set custom claims for role
      await adminAuth.setCustomUserClaims(uid, { role: u.role });

      // Create/update Firestore user doc
      await adminDb.collection("users").doc(uid).set({
        name: u.name,
        email: u.email,
        role: u.role,
        createdAt: new Date().toISOString(),
      }, { merge: true });

      // Create profile subcollection doc
      await adminDb
        .collection("users").doc(uid)
        .collection("profile").doc("main")
        .set({
          bio: u.bio || "",
          skills: u.skills || [],
          availability: u.availability || "",
          updatedAt: new Date().toISOString(),
        }, { merge: true });

      createdUsers.push({ uid, ...u });
    } catch (err) {
      console.error(`  ✗ Failed to create ${u.email}:`, err.message);
    }
  }

  const instructor = createdUsers.find((u) => u.role === "instructor");
  const students = createdUsers.filter((u) => u.role === "student");

  // 2. Create Teams
  const team1Ref = adminDb.collection("teams").doc();
  const team2Ref = adminDb.collection("teams").doc();
  await adminDb.batch()
    .set(team1Ref, {
      name: "Team Alpha",
      description: "Frontend development team",
      createdBy: instructor.uid,
      createdAt: new Date().toISOString(),
    })
    .set(team2Ref, {
      name: "Team Beta",
      description: "Backend API development team",
      createdBy: instructor.uid,
      createdAt: new Date().toISOString(),
    })
    .commit();
  console.log(`\n  + Team Alpha (${team1Ref.id})`);
  console.log(`  + Team Beta (${team2Ref.id})`);

  // 3. Create Team Members
  const batch = adminDb.batch();
  for (let i = 0; i < students.length; i++) {
    const teamRef = i < 6 ? team1Ref : team2Ref;
    const memberRef = adminDb.collection("teamMembers").doc();
    batch.set(memberRef, {
      teamId: teamRef.id,
      userId: students[i].uid,
      joinedAt: new Date().toISOString(),
      contribution: 0,
    });
  }
  await batch.commit();
  console.log(`  + Assigned ${students.length} students to teams`);

  // 4. Create Tasks
  const now = new Date().toISOString();
  const tasksBatch = adminDb.batch();
  const team1Students = students.slice(0, 6);
  const team2Students = students.slice(6);

  const taskData = [
    { title: "Design landing page", desc: "Create wireframes and mockups", status: "done", priority: "high", teamId: team1Ref, assignee: team1Students[0]?.uid },
    { title: "Implement authentication", desc: "Login and registration flow", status: "in-progress", priority: "high", teamId: team1Ref, assignee: team1Students[1]?.uid },
    { title: "Setup database schema", desc: "Create Firestore collections", status: "todo", priority: "medium", teamId: team1Ref, assignee: team1Students[2]?.uid },
    { title: "Write unit tests", desc: "Test core functionality", status: "todo", priority: "low", teamId: team1Ref, assignee: team1Students[3]?.uid },
    { title: "API endpoint design", desc: "Design REST API endpoints", status: "in-progress", priority: "high", teamId: team2Ref, assignee: team2Students[0]?.uid },
    { title: "Setup CI/CD pipeline", desc: "Configure GitHub Actions", status: "todo", priority: "medium", teamId: team2Ref, assignee: team2Students[1]?.uid },
  ];

  for (const t of taskData) {
    const ref = adminDb.collection("tasks").doc();
    tasksBatch.set(ref, {
      teamId: t.teamId.id,
      title: t.title,
      description: t.desc,
      status: t.status,
      priority: t.priority,
      assigneeId: t.assignee || null,
      assigneeName: t.assignee ? (taskData.find(u => u.assignee === t.assignee) ? null : null) : null,
      createdAt: now,
      updatedAt: now,
      dueDate: null,
    });
  }
  await tasksBatch.commit();
  console.log("  + Created 6 tasks");

  // 5. Create Chat Messages
  const msgBatch = adminDb.batch();
  const teams = [
    { ref: team1Ref, members: team1Students },
    { ref: team2Ref, members: team2Students },
  ];
  const messages = [
    "Hey team! Ready to start the project?",
    "Absolutely! I have completed the initial setup.",
    "Great work! Let us review the requirements together.",
    "I will start on the database schema today.",
  ];

  for (const team of teams) {
    for (let i = 0; i < messages.length; i++) {
      const ref = adminDb.collection("messages").doc();
      msgBatch.set(ref, {
        teamId: team.ref.id,
        senderId: team.members[i]?.uid || "",
        senderName: team.members[i]?.name || "Unknown",
        content: messages[i],
        timestamp: new Date(Date.now() - (messages.length - i) * 60000).toISOString(),
        fileName: null,
        fileSize: null,
      });
    }
  }
  await msgBatch.commit();
  console.log("  + Created 8 chat messages");

  // 6. Create Notifications (for the DIU test user)
  const testUser = createdUsers.find((u) => u.email === "nazmul242-35-859@diu.edu.bd");
  if (testUser) {
    const notifBatch = adminDb.batch();
    const notifs = [
      { type: "team", title: "Welcome to CampusNova!", description: "You have been added to Team Alpha", read: false },
      { type: "task", title: "New task assigned", description: "You have been assigned: Design landing page", read: false },
      { type: "message", title: "New message", description: "Masud sent a message in Team Alpha", read: true },
    ];
    for (const n of notifs) {
      const ref = adminDb.collection("notifications").doc();
      notifBatch.set(ref, {
        userId: testUser.uid,
        type: n.type,
        title: n.title,
        description: n.description,
        read: n.read,
        createdAt: new Date().toISOString(),
      });
    }
    await notifBatch.commit();
    console.log("  + Created 3 notifications");
  }

  console.log("\n=== Seed Complete ===");
  console.log(`Users: ${createdUsers.length} | Teams: 2 | Tasks: 6 | Messages: 8`);
  console.log("All passwords: password123\n");
}

seed().catch((e) => {
  console.error("Seed error:", e);
  process.exit(1);
});
